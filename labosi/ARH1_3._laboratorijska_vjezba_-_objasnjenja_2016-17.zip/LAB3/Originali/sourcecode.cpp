#include<stdio.h>
#include<stdlib.h>
#include<iostream>

using namespace std;

void spc(int x)
{
     while(x--)
     printf("\n");
}

char *dec2hex(int value)
{
	char *ret = (char*)malloc(3 * sizeof(char));
	
	int a = value >> 4;
	int b = value % 16;
	
	if(a > 9)
	ret[0] = 'F' - (15 - a);
	else
	ret[0] = '0' + a;
	
	if(b > 9)
	ret[1] = 'F' - (15 - b);
	else
	ret[1] = '0' + b;
	
	ret[2] = 0;
	
	return ret;
}

int main()
{
    char *str = (char*)malloc(sizeof(char));
    char c = 0;
    
    printf("\n  Upisite zeljeni znakovni niz, zavrsite ga s ENTERom:\n\n  ");
    
    for(int i = 0; c != 10; i++)
    {
    	c = getchar();
    	
    	realloc(str, i+2);
    	str[i] = c;
    }
    
    spc(3);
    printf("  Hex vrijednosti:\n  ");
    
    for(int i = 0; str[i+1] && str[i] != 10; i++)
    {
    	if(i && !(i%15))
    	cout << "\n  ";
    	
    	char *val = dec2hex(str[i]);
    	
    	printf("%s", val);
    	free(val);
    	
    	if(str[i+i] != 0 && str[i+1] != 10)
    	printf(", ");
    }

    spc(4);
    getchar();
    return 0;
}
