FERsh je program koji osvje�ava rje�enja preko interneta, tako da kad Edit na F2N-u timeout-a, ja mogu promijeniti rje�enja ukoliko bude neka gre�ka.
Svrha je neponavljanje blagoreceno zajeba sa ARH1 labosa. Priprema za rad ovog programa (koja je obavezna ukoliko �elite da radi) nalazi se na: http://materijali.fer2.net/File.28143.aspx
Ni�ta stra�no, manje od minute jednokratnog posla.

Ako ne �elite koristiti program, ili nemate 64-bitne Windowse, a�urirani kodovi nalaze se na:

Zadatak 5)			http://pastebin.com/raw/AVTzzqvQ
Z5 objasnjenja)		http://pastebin.com/raw/CgzxmyKJ
Zadatak 6)			http://pastebin.com/raw/0vuPCBNn
Z6 objasnjenja)		http://pastebin.com/raw/L9iqn5Zs

Takoder, uz ovu vje�bu dodao sam i programcic koji izbacuje hex vrijednosti za neki custom zapis na LCD-u, a dodao sam i source kod. Licenca CCBY, sve modifikacije dozvoljene u sklopu licence.
Neki put se bugga ispis pa su slijepljene vrijednosti, ali mislim da vam je lakse stavit ", " na par mjesta nego , na svako mjesto. Pretpostavljam da se to dogadja zbog nacina na koji getchar() radi. Oh well.



Kao i uvijek, ako dobivate neku gre�ku prilikom kompajliranja kodova, utipkajte "dos2unix %imedatoteke%", gdje umjesto %imedatoteke% upisete naziv datoteke (obicno Z#.a, gdje je # neki cijeli broj)
s kojom imate problema, a ako i nakon toga ne uspije kompajlanje, javite se na F2N, iako su svi kodovi testirani prije deploya i updateova.

Za bilo kakva druga pitanja ili primjedbe, javite se u box "Ljac" na F2N.