U 1. zadatku sam uradio neke modifikacije koje pitaju na eliminacijskim pitanjima
bez fixne... da nemamo fixni broj podataka nego da zavrsimo sa radom kad se ucita podatak 100
parnost ... u 1. zadatku izbrojati koliko ih je parnoga pariteta
prvidodatniuvjet...na labosu su trazili da komplementiramo brojeve koji su negativni i parni, da stavimo dodatni uvjet
prvizadatak .... ono sto se trazilo da se napravi za labos
vjezba0 i vjezba00 su iz pripreme za 1. laboratorijsku vjezbu